import javax.swing.JOptionPane;

/**
//***********************************************************************
'Project: Final Project Pt.1
'Programmer: Lukas Helmut Pfalz
'Company Info:  lhpfalz@mymail.csmd.edu  
'Date: 11 29 2020
'Description:  Main Program  
'    
'  	* Write a program that asks the user to enter the student information
'   using JOptionPane. The program will ask the user to enter:
'	- student ID - first/last name - major - grades (separated with commas)
'	* Create a Student Object with the info the user entered
'	* Verify the information with the user using JOptionPane to output the new
'	student object.
'	--------------------------------------------------------------------------
'   							HONOR CODE: 
'	I pledge that this program represents my own program code, I have received 
'	help from no one and I have given help to no one.
'-----------------------------------------------------------------------------
'
'  LINE LENGTH - AVOID LINES LONGER THAN 80 CHARACTERS
'  SCALE BELOW IS TO CALIBRATE SCREENSHOTS
'  DO NOT HAVE YOUR CODE OR SCREENSHOT EXTEND BEYOND THE SCALE
0........1.........2.........3.........4.........5.........6.........7.........8
12345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

public class LHPMainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Write a program to enter student info using
				
		/* Prompt the user to enter:
		 * - id - first name - last name - major
		 * - grades (separated by commas) */
		
		// 'studentInfo' String Array stores the info for the new student
		String[] studentInfo = {	"Student ID", "First Name", "Last Name",
								"Major", "Grades"};
		// Input uses a for-loop to prompt user to fill the info 
		for(int i = 0; i < studentInfo.length; i++)
			studentInfo[i] =	JOptionPane.showInputDialog(
								studentInfo[i] + ": ");
		// Student-Class Arguments initialized from "studentInfo" String Array
		String 	id = studentInfo[0], 
				first = studentInfo[1],
				last = studentInfo[2],
				major = studentInfo[3],
				grades = studentInfo[4];
		
		// Create a student object w info entered
		Student student_1 = new Student (id, first, last, major, grades);
		
		// Verify w the user the right info was given
		// by using JOptionPane to output the new student
		// object	
		JOptionPane.showMessageDialog(null, student_1.toString());
	}
}
