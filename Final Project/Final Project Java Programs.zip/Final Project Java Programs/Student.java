
public class Student {
	
	// Student ID, First Name, Last Name and Major
	// are store as strings
	public String 	studentID, firstName, lastName, 
					major;
	// Grades (int-array)
	public int[] grades;
	
	/**
	 * This 'Student' constructor defines the
	 * default-values for a student's information 
	 * (ID, first name, last name, and major.
	 */
	public Student() {
		studentID = "####";
		firstName = "First";
		lastName = "Last";
		major = "XXXX";
	}
	
	/**
	 * This 'Student' constructor defines a student's
	 * information (ID, first name, last name, and major)
	 * based what's defined by the user.
	 * 
	 * @param ID The student's ID stored in a string
	 * @param first The student's first name stored in a string
	 * @param last The student's last name stored in a string
	 * @param mjr The student's major stored in a string
	 */
	public Student(	String id, String first, String last, 
					String mjr) {
		studentID = id;
		firstName = first;
		lastName = last;
		major = mjr;
	}
	
	/**
	 * This 'Student' constructor defines a student's
	 * information (ID, first name, last name, major, and scores)
	 * based what's defined by the user.
	 * A for-loop is used to convert the user-defined string
	 * 'scores list' into an integer-array.
	 * 
	 * @param ID The student's ID stored in a string
	 * @param first The student's first name stored in a string
	 * @param last The student's last name stored in a string
	 * @param mjr The student's major stored in a string
	 * @param scoreStr A string storing a student's scores for a class
	 */
	public Student(	String ID, String first, String last,
					String mjr, String scoresList) {
		studentID = ID;
		firstName = first;
		lastName = last;
		major = mjr;
		
		String[] scores = scoresList.split(", ");
		int len = scores.length;
		grades = new int[len];
		for (int i = 0; i < len; i++)
			grades[i] = Integer.parseInt(scores[i]);
	}
	
	/**
	 * The setStudentID method lets a user set the string of the
	 * student's 'ID-number'
	 * 
	 * @param ID A string of a user-defined 'ID-number'
	 */
	public void setStudentID(String ID) {
		studentID = ID;
	}
	
	/**
	 * The setFirstName method lets a user set the string of the
	 * student's 'first-name'
	 * 
	 * @param first A string of a user-defined 'first-name'
	 */
	public void setFirstName(String first) {
		firstName = first;
	}
	
	/**
	 * The setLastName method lets a user set the string of the
	 * student's major 'last-name'
	 * 
	 * @param last A string of a user-defined 'last-name'
	 */
	public void setLastName(String last) {
		lastName = last;
	}
	
	/**
	 * The setMajor method lets a user set the string of the
	 * student's 'major'
	 * 
	 * @param mjr A string of a user-defined 'major'
	 */
	public void setMajor(String mjr) {
		major = mjr;
	}
	
	/**
	 * The getStudentID method returns the student's
	 * 'ID-number'
	 * 
	 * @return A string of a student's ID number
	 */
	public String getStudentID() {
		return studentID;
	}
	
	/**
	 * The getFirstName method returns a student's 'first-name'
	 * 
	 * @return A string of the student's 'first-name'
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * The getFirstName method returns a student's 'last-name'
	 * 
	 * @return A string of the student's 'last-name'
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * The getMajor method returns a student's major.
	 * 
	 * @return A string of the student's major
	 */
	public String getMajor() {
		return major;
	}
	
	/**
	 * The getName method returns the student's name by
	 * concatenating the student's first and last name.
	 * 
	 * @return A string containing the student's full-name
	 */
	public String getName()	{
		return firstName + " " + lastName;
	}
	
	/**
	 * The getAverageScore method calculates the student's
	 * 
	 * average score by diving the score-list's sum by the
	 * number of scores
	 * 
	 * @return The average score stored as an integer
	 */
	public int getAverageScore() {
		int num = 0;
		int len = grades.length;
		for(int i = 0; i < len; i++)
			num += grades[i];
		int avgScore = (int)(num / len);
		return avgScore;
	}
	
	/**
	 * The getGrade method returns the student's letter-grade
	 * based on the following scoring system:
	 * 90 to 100 is an A
	 * 80 to 89 is a B
	 * 70 to 79 is a C 
	 * 60 to 69 is a D
	 * 0 to 59 is an F
	 * 
	 * @return letter - The student's letter grade for a class
	 */
	public String getGrade() {
		int grade = getAverageScore();
		String letter;
		if(grade >= 90)
			letter = "A";
		else if (grade >= 80 && grade < 90)
			letter = "B";
		else if (grade >= 70 && grade < 80)
			letter = "C";
		else if (grade >= 60 && grade < 70)
			letter = "D";
		else
			letter = "F";			
		return letter;
	}
	
	/**
	 * The toString method formats all of the student's
	 * information as follows:
	 * Student ID: ####
	 * Name: First Last
	 * Major: XXXXX
	 * Scores: XX, XX, XX, XX, XX
	 * Average Score: XXXX
	 * Grade: X
	 * 
	 * @return A formatted string containing all of the given-
	 * student's information
	 */
	public String toString() {
		String str;
		str = String.format("Student ID: %s\nName: %s\nMajor: %s\nScores: ",
							getStudentID(), getName(), getMajor());
		int len = grades.length;
		for (int i = 0; i < len; i++) {
			String comma = i != len-1? ", " : "";
			str += grades[i] + comma;
		}
		str += String.format(	"\nAverage Score: %s\nGrade: %s", 
								getAverageScore(), getGrade());
		return str;
	}
}
