import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		
		/* Input - Extract Info from 'Student Records' */
		String inputFile = "student_records.txt";
		File file = new File(inputFile);
		Scanner keyboard = null;
		// Checks if 'input-file' can be located
		try {
			keyboard = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		List<String> rows = new ArrayList<String>();
		String nextRow;
		while(keyboard.hasNextLine()) {
			nextRow = keyboard.nextLine();
			rows.add(nextRow);
		}
		
		/* Convert Info arrays to Student Records */
		
		// length of 'Student' Array is initialized
		int len = rows.size();
		// Initialize 'Student' Array
		Student[] students = new Student[len];
		
		// 'Student' objects initialized
		for (int i = 0; i < len; i++) {
			// Info is extracted from the row
			String row = rows.get(i);
			String[] info = row.split(",");
			String ID, first, last, major, grades;
			// 'ID', 'first', 'last', 'major' are initialized
			// from row-elements from index of 0-3
			ID = info[0];
			String[] name = info[1].split(" ");
			first = name[0];
			last = name[1];
			major = info[2];
			System.out.println(row);
			// Establish 'grades-list' by appending the
			// Strings from index 3 to the end
			grades = info[3];
			for(int j = 4; j < info.length; j++)
				grades += ", " + info[j];
			
			// grades = info[3];
			students[i] =	new Student(ID, first, last,
             	            major, grades);
			System.out.println(students[i].toString());
		}
		
		//for (int i = 0; i < len; i++)
			//System.out.println(rows.get(i));
		keyboard.close();
	}
}