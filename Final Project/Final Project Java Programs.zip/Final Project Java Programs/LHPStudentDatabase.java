import java.io.*;
import java.util.*;

/**
//***********************************************************************
'Project: Final Project Pt.1
'Programmer: Lukas Helmut Pfalz
'Company Info:  lhpfalz@mymail.csmd.edu  
'Date: 11 30 2020
'Description:  Main Program
'	
'   Open file (student_records.txt) and extract
'	each row to construct a student object from row
'	--------------------------------------------------------------------------
'   							HONOR CODE: 
'	I pledge that this program represents my own program code, I have received 
'	help from no one and I have given help to no one.
'-----------------------------------------------------------------------------
'
'  LINE LENGTH - AVOID LINES LONGER THAN 80 CHARACTERS
'  SCALE BELOW IS TO CALIBRATE SCREENSHOTS
'  DO NOT HAVE YOUR CODE OR SCREENSHOT EXTEND BEYOND THE SCALE
0........1.........2.........3.........4.........5.........6.........7.........8
12345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

public class LHPStudentDatabase {
	public static void main(String[] args) {
		/* Input - Extract Info from 'Student Records' */
		String inputFile = "student_records.txt";
		File file = new File(inputFile);
		Scanner readFile = null;
		// Checks if 'input-file' can be located
		try {
			readFile = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		List<String> rows = new ArrayList<String>();
		String nextRow;
		while(readFile.hasNextLine()) {
			nextRow = readFile.nextLine();
			rows.add(nextRow);
		}
		// File is done being read, close 'readFile' Scanner
		readFile.close();
		/* Convert Info arrays to Student Records */
		
		// length of 'Student' Array is initialized
		int len = rows.size();
		// Initialize 'Student' Array
		Student[] students = new Student[len];
		
		// 'Student' objects initialized
		for (int i = 0; i < len; i++) {
			// Info is extracted from the row
			String row = rows.get(i);
			String[] info = row.split(",");
			String ID, first, last, major, grades;
			// 'ID', 'first', 'last', 'major' are initialized
			// from row-elements from index of 0-3
			ID = info[0];
			String[] name = info[1].split(" ");
			first = name[0];
			last = name[1];
			major = info[2];
			System.out.println(row);
			// Establish 'grades-list' by appending the
			// Strings from index 3 to the end
			grades = info[3];
			for(int j = 4; j < info.length; j++)
				grades += ", " + info[j];
			
			// grades = info[3];
			students[i] =	new Student(ID, first, last,
             	            major, grades);
			System.out.println(students[i].toString());
		}
		
		/* Output all student information to the console */
		for(int i = 0; i < len; i++)
			System.out.println( students[i].toString() );
		
		/* Ask User if they would like to modify their file */
		String prompt = "\nWould you like to save all student data to a file?"
						+ "\n(Enter \"Yes\" to save data)";
		
		// Keyboard Scanner used for prompting user
		Scanner keyboard = new Scanner(System.in);
		String saveData;
		System.out.println(prompt);
		saveData = keyboard.nextLine();
		keyboard.close();
		// String saveData = "Yes"; // Tester for 'RewriteFile' Function
		
		/* PrintWriter for modifying 'Student Records' is used */
		
		if(saveData.equals("Yes")) {
			RewriteFile(inputFile, students);
		}
		// Program is complete, exit the System
		System.exit(0);
	}

	private static void RewriteFile(String fileName, Student[] students) {
		// PrintWrite Class initialized
		PrintWriter inputFile = null;
		// Checks if 'input-file' can be located
		try {
			inputFile = new PrintWriter(fileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// Clear File Data
		inputFile.flush();
		
		/* Add new Lines in the file */
		// Student Records has 
		for(int i = 0; i < students.length; i++)
			inputFile.println( students[i].toString() );
		// Close out of 'Student Records' File
		inputFile.close();		
	}
}